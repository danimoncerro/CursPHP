<?php

require 'classes/Database.php';

$db = new Database();
$db->checkConnection();